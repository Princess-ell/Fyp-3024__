-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2024 at 03:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `localuxe`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(4) NOT NULL,
  `adminPassword` varchar(30) NOT NULL,
  `adminName` varchar(50) NOT NULL,
  `adminPhoneNo` varchar(30) NOT NULL,
  `adminEmail` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brandID` int(4) NOT NULL,
  `brandName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brandID`, `brandName`) VALUES
(1, 'Maaez'),
(2, 'Sobella'),
(3, 'Cubremi'),
(4, 'Bihan'),
(5, 'Simplysiti'),
(6, 'Alha Alfa'),
(7, ' Anas');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `shadeID` int(11) NOT NULL,
  `cartName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `cartItemID` int(11) NOT NULL,
  `cartID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `quantity` int(1) NOT NULL,
  `addedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categoryID` int(11) NOT NULL,
  `categoryName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categoryID`, `categoryName`) VALUES
(1, 'Foundation'),
(2, 'Powder'),
(3, 'Setting Spray'),
(4, 'Blusher'),
(5, 'Contour'),
(6, 'Highlighter'),
(7, 'Lipmatte'),
(8, 'Concealer'),
(9, 'Mascara'),
(10, 'Lipgloss'),
(11, 'Eyeliner'),
(12, 'Eyeshadow');

-- --------------------------------------------------------

--
-- Table structure for table `foundation`
--

CREATE TABLE `foundation` (
  `foundationID` int(11) NOT NULL,
  `foundationName` varchar(30) NOT NULL,
  `foundationPrice` decimal(10,2) NOT NULL,
  `foundationBrand` varchar(15) NOT NULL,
  `foundationDesc` text NOT NULL,
  `foundationImage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `orderDate` datetime NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `orderStatus` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `productName` varchar(50) NOT NULL,
  `productDesc` varchar(100) NOT NULL,
  `productPrice` decimal(10,2) NOT NULL,
  `productQuan` int(11) NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `brandID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productID`, `categoryID`, `productName`, `productDesc`, `productPrice`, `productQuan`, `productImage`, `brandID`) VALUES
(17, 1, 'Maaez foundation Make it glow', 'fd', 36.00, 3, 'makeitglow.jpeg', 1),
(18, 1, 'Maaez Luminious Silk Foundation', 'liquid foundation ', 69.90, 4, 'serumfd.jpeg', 1),
(24, 1, 'Elyna', 'haha', 150.00, 2, 'bihanfd.jpg', 1),
(25, 1, 'Elyna', 'haha', 150.00, 2, 'bihanfd.jpg', 1),
(26, 1, 'Coral Slingbag', 'hahah', 120.00, 4, 'bihanfd.jpg', 1),
(27, 1, 'iwan', 'huhu', 150.00, 2, '6737653fc14c2.jpg', 1),
(28, 1, 'iwan', 'huhu', 150.00, 2, '6737653fc14c2.jpg', 1),
(29, 1, 'Hermes', 'MM', 200.00, 5, 'bihanfd.jpg', 1),
(30, 1, 'Safea', 'Safea Dania', 2.00, 2, 'sobellablush.jpeg', 1),
(31, 2, 'powder pro', 'Safea Dania', 2.00, 2, 'sobellablush.jpeg', 1),
(32, 2, 'Hermes', '1232', 22222.00, 2, 'bihanfd.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `imageID` int(4) NOT NULL,
  `productID` int(4) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `imageName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`imageID`, `productID`, `imagePath`, `imageName`) VALUES
(3, 26, 'upload/cart.png', ''),
(4, 27, 'upload/bihanfd.jpg', ''),
(5, 28, 'upload/bihanfd.jpg', ''),
(6, 29, 'upload/67376526b8051.jpg', ''),
(7, 30, 'upload/sobellafd.jpeg', ''),
(8, 31, 'upload/sobellafd.jpeg', ''),
(9, 32, 'upload/', '');

-- --------------------------------------------------------

--
-- Table structure for table `product_shades`
--

CREATE TABLE `product_shades` (
  `shadeID` int(4) NOT NULL,
  `productID` int(4) NOT NULL,
  `shadeName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_shades`
--

INSERT INTO `product_shades` (`shadeID`, `productID`, `shadeName`) VALUES
(5, 24, 'cocoa'),
(6, 24, 'vanilla'),
(7, 25, 'cocoa'),
(8, 26, 'cocoa'),
(9, 27, 'ivory'),
(10, 27, 'ere'),
(11, 28, 'ivory'),
(12, 28, 'cocoa'),
(13, 29, 'cocoa'),
(14, 30, 'pokok'),
(15, 30, 'baby'),
(16, 31, 'memey'),
(17, 31, 'momoy'),
(18, 32, '');

-- --------------------------------------------------------

--
-- Table structure for table `tutorials`
--

CREATE TABLE `tutorials` (
  `tutorialID` int(4) NOT NULL,
  `title` varchar(255) NOT NULL,
  `videoURL` text NOT NULL,
  `description` text NOT NULL,
  `uploadedBy` varchar(255) NOT NULL,
  `uploadDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tutorials`
--

INSERT INTO `tutorials` (`tutorialID`, `title`, `videoURL`, `description`, `uploadedBy`, `uploadDate`) VALUES
(1, 'Cat eyes', 'https://www.youtube.com/watch?v=FNLWqW4uQgs&list=RDMMFNLWqW4uQgs&start_radio=1', 'elelele', 'Admin', '0000-00-00 00:00:00'),
(2, 'cat eyeeee', 'https://www.youtube.com/embed/FNLWqW4uQgs?si=OqFImpODJUsliHKg', 'cateyes', 'Admin', '0000-00-00 00:00:00'),
(3, 'aiman tino', 'https://www.youtube.com/embed/qTlJkKm9wbw?si=hF7pNVqFY5bvrmxN', 'elyna', 'Admin', '0000-00-00 00:00:00'),
(4, 'Safea', 'https://www.youtube.com/embed/qTlJkKm9wbw?si=hF7pNVqFY5bvrmxN', 'safea dania', 'Admin', '0000-00-00 00:00:00'),
(5, 'maaez', 'https://www.youtube.com/embed/qTlJkKm9wbw?si=rYduFbKPDORtG_-i', 'ugig', 'Admin', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tutorial_products`
--

CREATE TABLE `tutorial_products` (
  `tutorialpID` int(11) NOT NULL,
  `tutorialID` int(11) NOT NULL,
  `productID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tutorial_products`
--

INSERT INTO `tutorial_products` (`tutorialpID`, `tutorialID`, `productID`) VALUES
(1, 1, 18),
(2, 2, 25),
(3, 3, 17),
(4, 3, 18),
(5, 3, 24),
(6, 4, 17),
(7, 4, 18),
(8, 5, 18);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(4) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `userEmail` varchar(30) NOT NULL,
  `userPhoneNo` varchar(30) NOT NULL,
  `userPassword` varchar(30) NOT NULL,
  `userAddress` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `userName`, `userEmail`, `userPhoneNo`, `userPassword`, `userAddress`) VALUES
(1, 'Safea Dania', 'safea@gmail.com', '012-4536754', 'Safea123*', '15-08 the sky residence'),
(2, 'Dania adik', 'dania@gmail.com', '019-4357685', 'Dania123*', 'the sky residence'),
(3, 'Muhd Rahman Shah', 'cong@gmail.com', '019-4357685', 'Rahman123*', 'Taman bukit pasir'),
(5, 'Muhd Nur Izzuan', 'iwan@gmail.com', '016-8762435', 'Iwan123*', 'Jalan ayu 15 , taman prinsip ,');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brandID`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartID`),
  ADD KEY `foreignkey` (`productID`),
  ADD KEY `fkk` (`userID`),
  ADD KEY `foreignkeyyys` (`shadeID`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`cartItemID`),
  ADD KEY `ffkkf` (`cartID`),
  ADD KEY `ffkfkfk` (`productID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `foundation`
--
ALTER TABLE `foundation`
  ADD PRIMARY KEY (`foundationID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `frk` (`userID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `fk` (`categoryID`),
  ADD KEY `foreignkeyy` (`brandID`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`imageID`),
  ADD KEY `ffkk` (`productID`);

--
-- Indexes for table `product_shades`
--
ALTER TABLE `product_shades`
  ADD PRIMARY KEY (`shadeID`),
  ADD KEY `fkkfk` (`productID`);

--
-- Indexes for table `tutorials`
--
ALTER TABLE `tutorials`
  ADD PRIMARY KEY (`tutorialID`);

--
-- Indexes for table `tutorial_products`
--
ALTER TABLE `tutorial_products`
  ADD PRIMARY KEY (`tutorialpID`),
  ADD KEY `fkkk` (`tutorialID`),
  ADD KEY `ffkkk` (`productID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brandID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `cartItemID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `foundation`
--
ALTER TABLE `foundation`
  MODIFY `foundationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `imageID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_shades`
--
ALTER TABLE `product_shades`
  MODIFY `shadeID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tutorials`
--
ALTER TABLE `tutorials`
  MODIFY `tutorialID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tutorial_products`
--
ALTER TABLE `tutorial_products`
  MODIFY `tutorialpID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fkk` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `foreignkey` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  ADD CONSTRAINT `foreignkeyyys` FOREIGN KEY (`shadeID`) REFERENCES `product_shades` (`shadeID`);

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `ffkfkfk` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  ADD CONSTRAINT `ffkkf` FOREIGN KEY (`cartID`) REFERENCES `cart` (`cartID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `frk` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk` FOREIGN KEY (`categoryID`) REFERENCES `categories` (`categoryID`),
  ADD CONSTRAINT `foreignkeyy` FOREIGN KEY (`brandID`) REFERENCES `brands` (`brandID`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `ffkk` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`);

--
-- Constraints for table `product_shades`
--
ALTER TABLE `product_shades`
  ADD CONSTRAINT `fkkfk` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`);

--
-- Constraints for table `tutorial_products`
--
ALTER TABLE `tutorial_products`
  ADD CONSTRAINT `ffkkk` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  ADD CONSTRAINT `fkkk` FOREIGN KEY (`tutorialID`) REFERENCES `tutorials` (`tutorialID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
