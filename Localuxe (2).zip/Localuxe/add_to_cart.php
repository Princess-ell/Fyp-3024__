<?php
session_start();
include 'connection.php';

if (!isset($_SESSION['userID'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit();
}

// Check if POST data is set
if (!isset($_POST['productID']) || !isset($_POST['shadeID']) || !isset($_POST['productPrice']) || !isset($_POST['quantity'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
    exit();
}

$userID = $_SESSION['userID'];
$productID = $_POST['productID'];
$shadeID = $_POST['shadeID'];
$productPrice = $_POST['productPrice'];
$quantity = $_POST['quantity'];

// Get the shadeName from the product_shades table based on the shadeID
$shadeQuery = "SELECT shadeName FROM product_shades WHERE shadeID = '$shadeID'";
$shadeResult = mysqli_query($conn, $shadeQuery);
$shadeData = mysqli_fetch_assoc($shadeResult);

if ($shadeData) {
    $shadeName = $shadeData['shadeName'];
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid shade ID.']);
    exit();
}

// Check if the item already exists in the cart
$query = "SELECT * FROM cart WHERE userID = '$userID' AND productID = '$productID' AND shadeID = '$shadeID'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    // Update quantity if the item exists
    $updateQuery = "UPDATE cart SET quantity = quantity + '$quantity' WHERE userID = '$userID' AND productID = '$productID' AND shadeID = '$shadeID'";
    mysqli_query($conn, $updateQuery);
} else {
    // Insert new item into the cart
    $insertQuery = "INSERT INTO cart (userID, productID, shadeID, shadeName, productPrice, quantity) 
                    VALUES ('$userID', '$productID', '$shadeID', '$shadeName', '$productPrice', '$quantity')";
    mysqli_query($conn, $insertQuery);
}

// Get updated cart count
$cartCountQuery = "SELECT COUNT(*) AS cartCount FROM cart WHERE userID = '$userID'";
$cartCountResult = mysqli_query($conn, $cartCountQuery);
$cartCount = mysqli_fetch_assoc($cartCountResult)['cartCount'];

// Return success response with updated cart count
echo json_encode(['success' => true, 'cartCount' => $cartCount]);
?>
