<?php
session_start();
include 'connection.php';  // Include your database connection file

// Ensure user is logged in
if (!isset($_SESSION['userID'])) {
    header('Location: userLogin.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cartIDs = $_POST['cartID'];
    $quantities = $_POST['quantity'];

    foreach ($cartIDs as $index => $cartID) {
        $quantity = (int)$quantities[$index];
        if ($quantity > 0) {
            $sql = "UPDATE cart SET quantity = ? WHERE cartID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $quantity, $cartID);
            $stmt->execute();
        }
    }

    header('Location: cart.php'); // Redirect back to the cart page
    exit;
}
?>
