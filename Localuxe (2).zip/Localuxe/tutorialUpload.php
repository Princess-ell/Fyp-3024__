<?php
// Include database connection
include('connection.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $videoURL = $_POST['videoURL'];
    $description = $_POST['description'];
    $products = isset($_POST['products']) ? $_POST['products'] : []; // Array of product IDs

    // Validate video URL (ensure it's in embeddable format)
    if (!filter_var($videoURL, FILTER_VALIDATE_URL) || strpos($videoURL, "https://www.youtube.com/embed/") === false) {
        echo "Invalid YouTube embed URL. Please use the format: https://www.youtube.com/embed/...";
        exit;
    }

    // Insert tutorial into the tutorials table
    $stmt = $conn->prepare("INSERT INTO tutorials (title, videoURL, description, uploadedBy) VALUES (?, ?, ?, ?)");
    $uploadedBy = 'Admin'; // Replace with actual admin name or ID if available
    $stmt->bind_param("ssss", $title, $videoURL, $description, $uploadedBy);

    if ($stmt->execute()) {
        $tutorialID = $conn->insert_id; // Get the ID of the inserted tutorial

        // Insert associated products into tutorial_products table
        if (!empty($products)) {
            $stmt = $conn->prepare("INSERT INTO tutorial_products (tutorialID, productID) VALUES (?, ?)");

            foreach ($products as $productID) {
                $stmt->bind_param("ii", $tutorialID, $productID);
                if (!$stmt->execute()) {
                    echo "Error inserting product with ID $productID into tutorial_products: " . $stmt->error;
                }
            }
        }
        echo "Tutorial uploaded successfully!";
    } else {
        echo "Error uploading tutorial: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Tutorial</title>
</head>
<body>
    <h1>Upload New Tutorial</h1>
    <form action="tutorialUpload.php" method="POST">
        <label for="title">Tutorial Title:</label>
        <input type="text" id="title" name="title" required><br><br>

        <label for="videoURL">YouTube Embed URL:</label>
        <input type="url" id="videoURL" name="videoURL" required placeholder="https://www.youtube.com/embed/..."><br><br>

        <label for="description">Tutorial Description:</label>
        <textarea id="description" name="description" rows="4" required></textarea><br><br>

        <label for="products">Select Matching Products:</label>
        <select id="products" name="products[]" multiple>
            <?php
            // Fetch products from the database
            $result = $conn->query("SELECT productID, productName FROM products");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['productID'] . "'>" . $row['productName'] . "</option>";
            }
            ?>
        </select><br><br>

        <button type="submit">Upload Tutorial</button>
    </form>
</body>
</html>
