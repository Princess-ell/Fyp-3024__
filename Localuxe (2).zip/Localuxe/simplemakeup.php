<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Localuxe - Beauty & Makeup Tutorials</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <div class="header-container">
        <div class="logo">
            <h1>LOCALUXE</h1>
        </div>
        <!-- Icons Section -->
        <div class="header-icons">
            <!-- Search Icon -->
            <div class="search-icon" onclick="toggleSearch()">
                <img src="search.png" alt="Search">
            </div>
            <!-- Hidden Search Container -->
            <div class="search-container" id="search-container">
                <input type="text" placeholder="Search for products, brands, tutorials..." id="search-input">
                <button>Search</button>
            </div>

            <div class="love-icon">
    <a href="fav.php">
        <img src="heart.png" alt="Love">
    </a>
</div>

            <div class="sign-in-icon" onclick="toggleSignInMenu()">
    <img src="sign.png" alt="Sign In">
    <!-- Dropdown Menu -->
    <div class="dropdown-menu" id="dropdown-menu">
        <div class="dropdown-item" onclick="location.href='login.php'">Login</div>
        <div class="dropdown-item" onclick="location.href='register.php'">Register</div>
    </div>
</div>

            <div class="cart-icon">
                <img src="trolli.png" alt="Cart">
            </div>
        </div>
    </div>
    
</header>

<!-- Navigation Bar -->
<nav class="navbar">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="makeup.php" id="makeup-link">Makeup</a></li>
        <li><a href="tutorial.php" class="active">Tuts</a></li>
        <li><a href="skintone.php">Skin Tone</a></li>
        <?php
        session_start();
        if (isset($_SESSION['username'])) {
            echo '<li><a href="logout.php">Logout</a></li>';
        } else {
            echo '<li><a href="login.php">Login</a></li>';
        }
        ?>
    </ul>
</nav>

<section class="tutorial-video">
    <h2>Daily Makeup Look</h2>
    <div class="video-container">
        <!-- Embed the YouTube video -->
        <iframe width="1000" height="550" src="https://www.youtube.com/embed/2NKF2A6u-9U?si=ZAQgRvd8YM19EkWz" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


    </div>
</section>

<!-- Face Products Section -->
<div class="products-section">
    <h2>Face Products</h2>
    <div class="product-grid">
        <div class="product-card">
            <a href="makeitglow.php">
                <img src="makeitglow.jpeg" alt="Foundation">
            </a>
            <h4 class="product-name">Maaez Make It Glow</h4>
            <h4 class="product-type">Foundation</h4>
            <p class="product-price">RM29.90 - RM49.90</p>
            <button>Add to Cart</button>
            <button>Buy Now</button>
            <button>&hearts; Favorite</button>
        </div>
        <div class="product-card">
            <a href="makeitglow.php">
                <img src="makeitglow.jpeg" alt="Foundation">
            </a>
            <h4 class="product-name">Maaez Make It Glow</h4>
            <h4 class="product-type">Foundation</h4>
            <p class="product-price">RM29.90 - RM49.90</p>
            <button>Add to Cart</button>
            <button>Buy Now</button>
            <button>&hearts; Favorite</button>
        </div>
        <!-- Add more product cards here as needed -->
    </div>
</div>

<section class="comment-section">
    <h2>Leave a Comment</h2>
    <form action="submit_comment.php" method="POST">
        <textarea name="comment" rows="4" placeholder="Share your thoughts..."></textarea>
        <button type="submit">Post Comment</button>
    </form>
    <div class="comments-display">
        <h3>Recent Comments:</h3>
        <div class="comment-item">
            <p><strong>User1:</strong> Loved this tutorial! Can't wait to try it out!</p>
        </div>
        <div class="comment-item">
            <p><strong>User2:</strong> Great tips! The video was really helpful.</p>
        </div>
    </div>
</section>

<footer>
    <div class="footer-container">
        <div class="footer-section">
            <h3>About Us</h3>
            <ul>
                <li><a href="#">About Localuxe</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">International</a></li>
                <li><a href="#">Sitemap</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Customer Care</h3>
            <ul>
                <li><a href="#">Delivery</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Beauty Services</a></li>
                <li><a href="#">Store Events</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Beauty Rewards</h3>
            <img src="path_to_logo.png" alt="Localuxe Rewards">
            <button>Explore Benefits</button>
        </div>
        <div class="footer-section">
            <h3>Get the App</h3>
            <img src="path_to_qr_code.png" alt="QR Code">
            <div class="app-links">
                <a href="#"><img src="path_to_apple_store_badge.png" alt="App Store"></a>
                <a href="#"><img src="path_to_google_play_badge.png" alt="Google Play"></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Connect with Us</h3>
            <div class="social-icons">
                <a href="#"><img src="path_to_facebook_icon.png" alt="Facebook"></a>
                <a href="#"><img src="path_to_instagram_icon.png" alt="Instagram"></a>
            </div>
            <h3>Payment Options</h3>
            <div class="payment-icons">
                <img src="path_to_paypal_icon.png" alt="Paypal">
                <img src="path_to_visa_icon.png" alt="Visa">
                <img src="path_to_mastercard_icon.png" alt="Mastercard">
            </div>
        </div>
    </div>
</footer>

<script>
// Add your JavaScript code here if needed
// JavaScript for the search toggle
function toggleSearch() {
    var searchContainer = document.getElementById("search-container");
    
    if (searchContainer.classList.contains("active")) {
        // If currently active, remove the active class
        searchContainer.classList.remove("active");
        
        // Delay the hiding of display property to allow transition
        setTimeout(() => {
            searchContainer.style.display = 'none'; // Set display to none after transition
        }, 300); // Match the duration of your CSS transition
    } else {
        // If not active, show the search container
        searchContainer.style.display = 'flex'; // Show it as flex first
        searchContainer.classList.add("active");
        var searchInput = document.getElementById("search-input");
        searchInput.focus(); // Focus on the input field when search is activated
    }
}

function toggleSignInMenu() {
    var dropdownMenu = document.getElementById("dropdown-menu");
    
    if (dropdownMenu.style.display === "block") {
        dropdownMenu.style.display = "none"; // Hide if it's already displayed
    } else {
        dropdownMenu.style.display = "block"; // Show the dropdown menu
    }
}

// Close dropdown when clicking outside of it
document.addEventListener('click', function (e) {
    var dropdownMenu = document.getElementById("dropdown-menu");
    var signInIcon = document.querySelector('.sign-in-icon');
    
    if (!dropdownMenu.contains(e.target) && !signInIcon.contains(e.target)) {
        dropdownMenu.style.display = 'none'; // Hide the dropdown
    }
});
</script>

<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    cursor: url('cursorr.png'), auto !important;
    
}

/* Header Section */
.header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    background-color: white;
    position: relative; /* Keep it relative for absolute positioning */
}

.header-icons {
    display: flex; /* Ensure icons are aligned horizontally */
    align-items: center; /* Center vertically */
}


.logo h1 {
    margin: 0;
    font-size: 36px;
    color: black;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    margin-left: 15px;
}

.search-container {
    display: none; /* Hidden by default */
    position: absolute; /* Position absolutely */
    left: 50%; /* Center horizontally */
    top: 50%; /* Center vertically */
    transform: translate(-50%, -50%); /* Adjust for centering */
    z-index: 1000; /* Keep it above other elements */
}

/* Show the search bar when the class 'active' is added */
.search-container.active {
    display: flex; /* Change to flex to make it clickable */
    align-items: center; /* Center items inside */
}

/* Style for input and button */
#search-input {
    padding: 8px; /* Add padding */
    border: 1px solid #ccc; /* Add border */
    border-radius: 4px; /* Rounded corners */
    margin-right: 5px; /* Space between input and button */
}

.search-icon img {
    width: 25px;
    height: 25px;
}

.love-icon {
    margin-left: 10px; /* Adjust spacing as needed */
    cursor: pointer; /* Change cursor to pointer */
}

.love-icon img {
    width: 20px; /* Adjust the size of the love icon */
    height: 20px; /* Keep the height consistent with other icons */
}

.sign-in-icon {
    margin-left: 5px;
    position: relative; /* Required for dropdown positioning */
    cursor: pointer; /* Change cursor to pointer */
}

/* Sign In and Cart Icons */
.cart-icon {
    margin-left: 5px;
    cursor: pointer;
}

.sign-in-icon img {
    width: 40px; /* Adjust the size of the icons */
    height: 40px;
}

.dropdown-menu {
    display: none; /* Initially hidden */
    position: absolute; /* Position it below the sign-in icon */
    top: 100%; /* Align it directly under the icon */
    left: 50%; /* Center it */
    transform: translateX(-50%); /* Center alignment */
    background-color: white; /* Background color */
    border: 1px solid black; /* Border for visibility */
    border-radius: 4px; /* Rounded corners */
    z-index: 100; /* Ensure it appears above other elements */
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Optional shadow */
}

.dropdown-item {
    padding: 10px 15px; /* Add padding for items */
    cursor: pointer; /* Pointer cursor */
}

.dropdown-item:hover {
    background-color: #f0f0f0; /* Hover effect */
}

.cart-icon img {
    width: 30px;
    height: 30px;
}

/* Centering and Styling the Navigation Bar */
.navbar {
    background-color: rgba(187, 115, 73, 0.993);
    padding: 15px;
    display: flex;
    justify-content: center; /* Center the nav items */
    align-items: center; /* Vertically align the items */
}

.navbar ul {
    list-style-type: none;
    display: flex;
}

.navbar ul li {
    margin: 0 20px;
}

.navbar ul li a {
    color: white;
    text-decoration: none;
    font-size: 18px;
    padding: 8px 16px;
    font-family: 'Times New Roman', Times, serif;
}

.navbar ul li a:hover {
    background-color: black;
    border-radius: 4px;
}

/* Styling for the Tutorial Section */
.tutorial-video {
    text-align: center;
    margin: 20px auto;
    max-width: 1000px; /* Limit max width */
}

.video-container video {
    width: 100%;
    max-width: 600px;
    height: auto;
    cursor: pointer; /* Indicate it's clickable */
}

.video-container {
    position: relative;
    overflow: hidden;
    padding-top: 56.25%; /* 16:9 Aspect Ratio */
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Add a shadow for effect */
    margin: auto;
    max-width: 100%;
}

.video-container iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 0;
    border-radius: 12px;
}

/* Comments Section */
.comment-section {
    background-color: #fff;
    padding: 30px 20px;
    margin: 20px auto;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}

.comment-section h2 {
    text-align: center;
    font-size: 28px;
    margin-bottom: 20px;
    color: #bb7349;
}

.comment-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 30px;
}

.comment-form textarea {
    padding: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    resize: none;
}

.comment-form button {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    background-color: #bb7349;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.comment-form button:hover {
    background-color: #9d5e3e;
}

.comments-display h3 {
    margin-bottom: 20px;
    font-size: 22px;
    color: #333;
}

.comment-item {
    background-color: #f9f9f9;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 15px;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
}

.comment-item p {
    font-size: 16px;
    color: #555;
}

.products-section {
  display: flex;
  flex-wrap: wrap;
  gap: 20px; /* Space between the products */
  justify-content: center; /* Center align the items */
  padding: 20px;
}


.product-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; /* Space between product cards */
    justify-content: flex-start; /* Aligns products evenly */
}



.product-card {
  flex: 1 1 calc(25% - 20px); /* Adjust width to fit 4 items per row with gap */
  max-width: calc(25% - 20px); /* Maximum width for each item */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow around the card */
  border-radius: 8px; /* Rounded corners for a clean look */
  overflow: hidden; /* Ensures content stays inside card */
  background-color: #fff;
  padding: 15px;
  text-align: center;
  transition: transform 0.3s ease; /* Hover effect */
}


.product-card:hover {
  transform: scale(1.05); /* Scale slightly on hover */
}


.product-card img {
  width: 100%; /* Make image take full width of container */
  height: auto;
  border-radius: 4px;
}

.product-card h4 {
    margin: 10px 0;
    font-size: 16px;
    color: #444;
}

.product-card p {
    color: #777;
    margin-bottom: 15px;
}

.product-type, .product-name, .product-price {
    margin: 5px 0;
}

.product-type {
    font-size: 14px;
    color: #888; /* Lighter color for type */
}

.product-name {
    font-size: 16px;
    color: #444; /* Slightly darker */
}

.product-price {
    font-size: 15px;
    color: #b16c59; /* Accent color */
    font-weight: bold;
}

.product-card h3 {
  font-size: 1rem;
  margin: 10px 0;
  color: #333;
}

.product-card p {
  font-size: 0.9rem;
  color: #777;
  margin: 5px 0;
}

/* Optional: Adjust the styling of the "Face" products if they have a specific class */
.face-product-card {
  border: 2px solid #f0c0c0; /* Optional: add a unique border color */
  background-color: #fef7f7; /* Optional: light background color */
}

.button-container {
    display: flex;
    justify-content: space-around;
    margin-top: 10px;
}

button {
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.add-to-cart-btn {
    background-color: #b16c59;
    color: #fff;
}

.buy-now-btn {
    background-color: #4CAF50;
    color: #fff;
}

.love-btn {
    background-color: #f44336;
    color: #fff;
}

button:hover {
    opacity: 0.9;
}

/* Footer Styling */
footer {
    background-color: black;
    padding: 40px 20px;
    /* Make sure footer takes full width */
    width: 100%;
}

/* Main footer container using flexbox */
.footer-container {
    display: flex;
    justify-content: space-between; /* Even spacing between sections */
    flex-wrap: wrap; /* Allow wrapping on smaller screens */
    gap: 20px; /* Space between items */
    max-width: 1200px; /* Ensure container has a max width */
    margin: 0 auto; /* Center the footer */
}

/* Individual sections take up equal space */
.footer-section {
    flex: 1;
    min-width: 200px; /* Ensure minimum width for smaller screens */
}

/* Styling for heading */
.footer-section h3 {
    margin-bottom: 20px;
    font-size: 16px;
    font-weight: bold;
    color: white;
}

/* Links in the footer */
.footer-section ul {
    list-style: none;
    padding: 0;
    
}

.footer-section ul li {
    margin-bottom: 10px;
    color: white;
}

.footer-section ul li a {
    text-decoration: none;
    color: white;
}

.footer-section ul li a:hover {
    text-decoration: underline;
}

/* Make sure images like logos or QR codes don't exceed their container */
.footer-section img {
    max-width: 100%;
}

/* Style buttons */
.footer-section button {
    padding: 10px 20px;
    background-color: #000;
    color: #fff;
    border: none;
    cursor: pointer;
}

/* Styling for app download section */
.footer-section .app-links img {
    width: 120px;
    margin: 10px 0;
}

/* Social and payment icons */
.social-icons img, .payment-icons img {
    width: 40px;
    margin-right: 10px;
}

/* Align icons in a horizontal row */
.payment-icons img {
    margin-bottom: 10px;
}

</style>
</body>
</html>