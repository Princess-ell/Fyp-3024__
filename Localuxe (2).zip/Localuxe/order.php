<?php
// Start session to access user information
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header('Location: userLogin.php');
    exit();
}

// Call file to connect server
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get user information from session
    $userID = $_SESSION['userID'];
    $userName = $_SESSION['userName'];
    $userEmail = $_SESSION['userEmail'];
    $userPhoneNo = $_SESSION['userPhoneNo'];
    $userAddress = $_SESSION['userAddress'];

    // Process the order and insert it into the orders table
    $orderQuery = "INSERT INTO orders (userID, userName, userEmail, userPhoneNo, userAddress, orderDate) 
                   VALUES ('$userID', '$userName', '$userEmail', '$userPhoneNo', '$userAddress', NOW())";

    if (mysqli_query($conn, $orderQuery)) {
        // Get the order ID
        $orderID = mysqli_insert_id($conn);

        // Add the products in the cart to the order
        $cartQuery = "SELECT * FROM cart WHERE userID = '$userID'";
        $cartResult = mysqli_query($conn, $cartQuery);

        while ($cartItem = mysqli_fetch_assoc($cartResult)) {
            $productID = $cartItem['productID'];
            $quantity = $cartItem['quantity'];

            // Insert the order items into the order_details table
            $orderDetailsQuery = "INSERT INTO order_details (orderID, productID, quantity) 
                                  VALUES ('$orderID', '$productID', '$quantity')";
            mysqli_query($conn, $orderDetailsQuery);
        }

        // Clear the user's cart after placing the order
        $clearCartQuery = "DELETE FROM cart WHERE userID = '$userID'";
        mysqli_query($conn, $clearCartQuery);

        // Redirect the user to a confirmation page or admin notification
        echo "Order placed successfully!";
        // Send the order details to admin (via email, or simply display it)
    } else {
        echo "Error processing the order.";
    }
}

?>
