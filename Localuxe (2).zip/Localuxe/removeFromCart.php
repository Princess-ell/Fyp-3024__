<?php
session_start();
include 'connection.php';  // Include your database connection file

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header('Location: userLogin.php');  // Redirect to login page if not logged in
    exit;
}

$userID = $_SESSION['userID'];

// Check if the cartID is provided in the URL
if (isset($_GET['cartID'])) {
    $cartID = $_GET['cartID'];

    // Delete the product from the cart
    $sql = "DELETE FROM cart WHERE cartID = ? AND userID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $cartID, $userID);

    if ($stmt->execute()) {
        // Redirect back to the cart page after removing the product
        header('Location: cart.php');
        exit;
    } else {
        echo "Error removing product from cart.";
    }
} else {
    echo "No product selected for removal.";
}
?>
