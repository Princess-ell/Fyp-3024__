<?php
session_start();
include 'db.php';  // Include your database connection file

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header('Location: login.php');  // Redirect to login page if user is not logged in
    exit;
}

$userID = $_SESSION['userID'];
$productID = $_POST['productID'];
$quantity = $_POST['quantity'];

// Check if the product is already in the cart
$sql = "SELECT * FROM cart WHERE userID = ? AND productID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $userID, $productID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Product is already in the cart, update the quantity
    $sql = "UPDATE cart SET quantity = quantity + ? WHERE userID = ? AND productID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $quantity, $userID, $productID);
    $stmt->execute();
} else {
    // Product is not in the cart, insert it
    $sql = "INSERT INTO cart (userID, productID, quantity) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $userID, $productID, $quantity);
    $stmt->execute();
}

header('Location: cart.php');  // Redirect to the cart page
exit;
?>
